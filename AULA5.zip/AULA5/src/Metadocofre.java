import javax.swing.JOptionPane;
public class Metadocofre {
    static void main() {
        double TotalNocofre = 0;
        while (TotalNocofre < 50){
            String deposito= JOptionPane.showInputDialog("Total no cofre: R$" + TotalNocofre + "\n Qunato vai depositar agora?");;;
            double valor = Double.parseDouble(deposito);;
            TotalNocofre += valor;
        }
        JOptionPane.showMessageDialog(null, "Voce conseguiu batersua meta!" + TotalNocofre+ "Meta batida!");


    }
}
