import javax.swing.*;

public class adivinha {
    static void main() {
        double número = 30;
            String valor = JOptionPane.showInputDialog("Adivinhe um número de 1 a 100");
                if (número != 30) {
                    JOptionPane.showMessageDialog(null, "Errou! Tente depois");
                    if (número == 30) {
                        JOptionPane.showMessageDialog(null, "Uau! Voce é incrível!");
                    }
                }

            }
        }





