public class CONTADORWHILE {
    static void main() {
        int energia = 5;
        while (energia > 0) {
            System.out.println("O herói ainda está de pé! Energia atual: " + energia);
            energia--;
            System.out.println("Game over! O herói caiu!");
        }
    }
}
