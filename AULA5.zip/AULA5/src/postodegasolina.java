import javax.swing.JOptionPane;
public class postodegasolina {
    static void main() {
        int litrosdagasolina = 5;
        while(litrosdagasolina != 50){
        JOptionPane.showMessageDialog(null,"O carro está abastecendo! "  + litrosdagasolina);
        litrosdagasolina+=5;
        if (litrosdagasolina == 50){
            JOptionPane.showMessageDialog(null,"Tanque cheio! Já pode partit ");
        }
        }

    }
}
