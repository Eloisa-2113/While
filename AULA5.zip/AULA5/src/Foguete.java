public class Foguete {
    static void main() {
        int contagem = 10;
        while (contagem >= 0)
        {
            if (contagem == 0) {
                System.out.println("0 - FOGO! ");
            } else {
                System.out.println(contagem + "....");
            }
            contagem--;
        }
    }
}
