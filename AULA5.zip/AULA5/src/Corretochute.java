import javax.swing.JOptionPane;
public class Corretochute {
    static void main() {
        int Numerosecreto = 69;
        int chute = 0;
        while (chute != Numerosecreto) {
            chute = Integer.parseInt(JOptionPane.showInputDialog("Adivinhe o número de 1 a 100"));
            if (chute != Numerosecreto) {
                JOptionPane.showMessageDialog(null, "Errou feio!");

                JOptionPane.showMessageDialog(null, "Ai sim!, Acertou!");
                }
            }


        }

    }



