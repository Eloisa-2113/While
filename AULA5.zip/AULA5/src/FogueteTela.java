import javax.swing.JOptionPane;
public class FogueteTela {
    static void main() {
        int contagem = 10;
        while(contagem>=0){
            JOptionPane.showMessageDialog(null, "Conatgem:" + contagem );
            contagem--;
        }
        JOptionPane.showMessageDialog(null, "Fire!!! \uD83D\uDD25");
    }
}
